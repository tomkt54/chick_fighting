window.__require = function e(t, n, r) {
  function s(o, u) {
    if (!n[o]) {
      if (!t[o]) {
        var b = o.split("/");
        b = b[b.length - 1];
        if (!t[b]) {
          var a = "function" == typeof __require && __require;
          if (!u && a) return a(b, !0);
          if (i) return i(b, !0);
          throw new Error("Cannot find module '" + o + "'");
        }
      }
      var f = n[o] = {
        exports: {}
      };
      t[o][0].call(f.exports, function(e) {
        var n = t[o][1][e];
        return s(n || e);
      }, f, f.exports, e, t, n, r);
    }
    return n[o].exports;
  }
  var i = "function" == typeof __require && __require;
  for (var o = 0; o < r.length; o++) s(r[o]);
  return s;
}({
  BaseSkill: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "fe322SHMHRP27PUq6zZqsOE", "BaseSkill");
    "use strict";
    var __extends = this && this.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function(d, b) {
          d.__proto__ = b;
        } || function(d, b) {
          for (var p in b) b.hasOwnProperty(p) && (d[p] = b[p]);
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = null === b ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var BaseWarrior_1 = require("./BaseWarrior");
    var VBaseNode_1 = require("./VBaseNode");
    var VBaseTransform_1 = require("./VBaseTransform");
    var BaseSkill = function(_super) {
      __extends(BaseSkill, _super);
      function BaseSkill() {
        var _this = _super.call(this) || this;
        _this.damage = 10;
        _this.hitProb = 1;
        _this.prepareDur = 0;
        _this.doneStunDur = 0;
        _this.reset();
        return _this;
      }
      BaseSkill.prototype.reset = function() {
        this.reserveTime = 0;
        this.isDone = true;
        this.active = false;
        this.prepareTime = this.prepareDur;
      };
      BaseSkill.prototype.setOwner = function(owner) {
        this.owner = owner;
        this.reset();
      };
      BaseSkill.prototype.start = function() {
        this.reset();
        this.isDone = false;
        this.active = true;
      };
      BaseSkill.prototype.done = function() {
        if (this.isDone) return;
        this.owner.onSkillDone();
        this.owner.setStunFor(this.doneStunDur);
        this.owner.reserveTime = this.reserveTime;
        this.isDone = true;
      };
      BaseSkill.prototype.checkSkillDone = function() {
        return false;
      };
      BaseSkill.prototype.update = function(dt) {
        this.checkSkillDone() && this.done();
      };
      BaseSkill.prototype.deactive = function() {
        this.active = false;
      };
      return BaseSkill;
    }(VBaseNode_1.VBaseNode);
    exports.BaseSkill = BaseSkill;
    var KickSkill = function(_super) {
      __extends(KickSkill, _super);
      function KickSkill() {
        var _this = _super.call(this) || this;
        _this.hitPos = new VBaseTransform_1.VVec2();
        _this.lastIsOnGround = true;
        _this.damage = 25;
        _this.doneStunDur = .1;
        _this.alwaysAttack = false;
        return _this;
      }
      KickSkill.prototype.setOwner = function(owner) {
        _super.prototype.setOwner.call(this, owner);
        this.hitPos.x = 1.6 * owner.hitRadius;
        this.hitPos.y = .2 * -owner.hitRadius;
      };
      KickSkill.prototype.reset = function() {
        _super.prototype.reset.call(this);
        this.lastIsOnGround = true;
        this.prepareDur = .1;
        this.reserveTime = .1;
      };
      KickSkill.prototype.start = function() {
        _super.prototype.start.call(this);
        this.alwaysAttack = this.owner.world.getRand() < .3;
        var owner = this.owner;
        var dis = Math.abs(this.owner.x - this.owner.enemy.x);
        this.skillVx = dis * (1.2 + .8 * this.owner.world.getRand());
        this.skillVy = 850 + 300 * this.owner.world.getRand();
        owner.vx = owner.dir * this.skillVx;
        owner.vy = this.skillVy;
        this.lastIsOnGround = true;
      };
      KickSkill.prototype.done = function() {
        _super.prototype.done.call(this);
        cc.log("kick done.");
      };
      KickSkill.prototype.calLandingDur = function() {
        return 1;
      };
      KickSkill.prototype.checkSkillDone = function() {
        if (!this.lastIsOnGround && this.owner.getIsOnGround()) return true;
        this.lastIsOnGround = this.owner.getIsOnGround();
        return false;
      };
      KickSkill.prototype.checkWillAttack = function() {
        if (this.alwaysAttack) return true;
        var dis = Math.abs(this.owner.y - this.owner.enemy.y);
        if (!this.owner.enemy.isOnGround) return true;
        return false;
      };
      KickSkill.prototype.update = function(dt) {
        _super.prototype.update.call(this, dt);
        this.owner.vy < 0 && Math.abs(this.owner.vy) > .1 * this.skillVy && this.owner.setAnimState(BaseWarrior_1.WarriorAnimState.LANDING);
        if (!this.active) return;
        if (this.prepareTime > 0) {
          this.prepareTime -= dt;
          this.prepareTime <= 0 && this.owner.setAnimState(BaseWarrior_1.WarriorAnimState.JUMP_HIGHT_BACKWARD);
          return;
        }
        this.owner.vy > 0 && (this.owner.vy < .1 * this.skillVy ? this.owner.setAnimState(BaseWarrior_1.WarriorAnimState.JUMP_HIGHT_FORWARD) : this.owner.vy < .95 * this.skillVy && this.checkWillAttack() && this.owner.setAnimState(BaseWarrior_1.WarriorAnimState.ATTACK_MIDDLE_1));
        var owner = this.owner;
        var enemy = this.owner.enemy;
        if (this.checkWillAttack() && this.owner.vy > 0 && this.owner.vy < .9 * this.skillVy) {
          var p = owner.toGlobal(this.hitPos);
          var v = new VBaseTransform_1.VVec2(p.x - enemy.x, p.y - enemy.y);
          var dis = Math.sqrt(v.x * v.x + v.y * v.y);
          if (dis < enemy.hitRadius) {
            enemy.vy -= 30;
            var critical = this.owner.world.getRand() * this.damage * .3;
            enemy.hurt(this.damage + critical, 1);
            this.deactive();
            return;
          }
        }
      };
      return KickSkill;
    }(BaseSkill);
    exports.KickSkill = KickSkill;
    var LowDodgeSkill = function(_super) {
      __extends(LowDodgeSkill, _super);
      function LowDodgeSkill() {
        return _super.call(this) || this;
      }
      LowDodgeSkill.prototype.reset = function() {
        _super.prototype.reset.call(this);
        this.startX = 0;
        this.dodgeDis = 200;
        this.prepareDur = .1;
        this.moveVal = 0;
      };
      LowDodgeSkill.prototype.setOwner = function(owner) {
        _super.prototype.setOwner.call(this, owner);
      };
      LowDodgeSkill.prototype.done = function() {
        _super.prototype.done.call(this);
        this.owner.setAnimState(BaseWarrior_1.WarriorAnimState.FIGHTING_IDLE);
        this.owner.moveVal = this.moveVal;
        this.owner.targetScaleY = this.owner.defaultScaleY;
      };
      LowDodgeSkill.prototype.start = function() {
        _super.prototype.start.call(this);
        this.startX = this.owner.x;
        this.prepareDur = .2 * this.owner.world.getRand();
        this.owner.targetScaleY = .8 * this.owner.defaultScaleY;
      };
      LowDodgeSkill.prototype.checkSkillDone = function() {
        if (Math.abs(this.owner.x - this.startX) > this.dodgeDis) return true;
        return false;
      };
      LowDodgeSkill.prototype.update = function(dt) {
        _super.prototype.update.call(this, dt);
        if (!this.active) return;
        if (this.prepareTime > 0) {
          this.prepareTime -= dt;
          this.prepareTime <= 0 && this.owner.setAnimState(BaseWarrior_1.WarriorAnimState.RUN);
          return;
        }
        var val = Math.abs(this.moveVal);
        val += .05 * this.owner.moveSpeed;
        val > this.owner.moveSpeed && (val = this.owner.moveSpeed);
        this.moveVal = this.owner.dir * val;
        this.owner.x += this.moveVal * dt * 1.5;
        this.owner.moveVal = this.moveVal;
      };
      return LowDodgeSkill;
    }(BaseSkill);
    exports.LowDodgeSkill = LowDodgeSkill;
    cc._RF.pop();
  }, {
    "./BaseWarrior": "BaseWarrior",
    "./VBaseNode": "VBaseNode",
    "./VBaseTransform": "VBaseTransform"
  } ],
  BaseWarrior: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "4e8dcsvpp1JWIw+2dX52t/F", "BaseWarrior");
    "use strict";
    var __extends = this && this.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function(d, b) {
          d.__proto__ = b;
        } || function(d, b) {
          for (var p in b) b.hasOwnProperty(p) && (d[p] = b[p]);
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = null === b ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var EnvSettings_1 = require("./EnvSettings");
    var VBaseNode_1 = require("./VBaseNode");
    var WarriorDir = function() {
      function WarriorDir() {}
      WarriorDir.TO_LEFT = 1;
      WarriorDir.TO_RIGHT = -1;
      return WarriorDir;
    }();
    exports.WarriorDir = WarriorDir;
    var WarriorCommonState = function() {
      function WarriorCommonState() {}
      WarriorCommonState.IDLE = 0;
      WarriorCommonState.ACTIVE = 1;
      WarriorCommonState.STUN = 2;
      WarriorCommonState.FIGHTING = 3;
      WarriorCommonState.DIE = 4;
      WarriorCommonState.WIN = 5;
      WarriorCommonState.STUN_DOWN = 6;
      return WarriorCommonState;
    }();
    exports.WarriorCommonState = WarriorCommonState;
    var WarriorFightingState = function() {
      function WarriorFightingState() {}
      WarriorFightingState.DODGE_MOVING = 100;
      WarriorFightingState.JUMPING = 101;
      WarriorFightingState.KICKING = 102;
      WarriorFightingState.LANDING = 103;
      WarriorFightingState.FALLING = 104;
      WarriorFightingState.HEAD_ATTACK = 105;
      return WarriorFightingState;
    }();
    exports.WarriorFightingState = WarriorFightingState;
    var WarriorAnimState = function() {
      function WarriorAnimState() {}
      WarriorAnimState.IDLE = 0;
      WarriorAnimState.STUN = 1;
      WarriorAnimState.KICK = 2;
      WarriorAnimState.LANDING = 3;
      WarriorAnimState.FALLING = 4;
      WarriorAnimState.WALK = 5;
      WarriorAnimState.RUN = 6;
      WarriorAnimState.BACKWARD = 7;
      WarriorAnimState.CHANGE_DIR = 8;
      WarriorAnimState.FIGHTING_IDLE = 9;
      WarriorAnimState.DOWN = 10;
      WarriorAnimState.CROUCH = 20;
      WarriorAnimState.JUMP_HIGHT_FORWARD = 21;
      WarriorAnimState.JUMP_HIGHT_BACKWARD = 22;
      WarriorAnimState.ATTACK_MIDDLE_1 = 23;
      WarriorAnimState.DIE = 24;
      WarriorAnimState.WIN = 25;
      return WarriorAnimState;
    }();
    exports.WarriorAnimState = WarriorAnimState;
    var BaseWarrior = function(_super) {
      __extends(BaseWarrior, _super);
      function BaseWarrior(world) {
        var _this = _super.call(this) || this;
        _this.skills = [];
        _this.world = world;
        _this.stateTransitionDurMap = {};
        _this.transDurMap = {};
        _this.mixAnimTime = 0;
        _this.baseHeight = 60;
        _this.hitRadius = 40;
        _this.moveSpeed = 600;
        _this.attackRange = 300;
        _this.attackRange = 300;
        _this.winDur = 1.5;
        _this.minAttackRange = .6 * _this.attackRange;
        _this.ga = 1 * EnvSettings_1.default.ga;
        _this.af = 1 * EnvSettings_1.default.af;
        _this.totalHp = 100;
        _this.anim = null;
        _this.animStateMap = {};
        _this.animLoopMap = {};
        _this.curAnimState = -1;
        _this.anim = null;
        _this.reset();
        return _this;
      }
      BaseWarrior.prototype.reset = function() {
        this.vx = 0;
        this.vy = 0;
        this.enemy = null;
        this.activeSkill = null;
        this.state = WarriorCommonState.IDLE;
        this.isOnGround = true;
        this.lastIsOnGround = true;
        this.dir = 1;
        this.stunTime = 0;
        this.stunDownTime = 0;
        this.stunWait = 0;
        this.moveVal = 0;
        this.reserveTime = 0;
        this.winTime = 0;
        this.isDie = false;
        this.isWin = false;
        this.resetTransform();
        for (var i = 0; i < this.skills.length; i++) this.skills[i].reset();
        this.hp = this.totalHp;
      };
      BaseWarrior.prototype.setAnim = function(anim) {
        this.anim = anim;
        this.defaultScaleY = this.anim.scaleY;
        this.targetScaleY = this.anim.scaleY;
      };
      BaseWarrior.prototype.getMoveVal = function() {
        return this.moveVal;
      };
      BaseWarrior.prototype.getHp = function() {
        return this.hp;
      };
      BaseWarrior.prototype.setState = function(state) {
        this.state = state;
      };
      BaseWarrior.prototype.getIsOnGround = function() {
        return this.isOnGround;
      };
      BaseWarrior.prototype.setAnimState = function(animState) {
        if (this.curAnimState == animState) return;
        this.mixAnim(animState);
      };
      BaseWarrior.prototype.playAnim = function(state) {};
      BaseWarrior.prototype.mixAnim = function(animState) {};
      BaseWarrior.prototype.update = function(dt) {
        _super.prototype.update.call(this, dt);
        this.y > 0 && (this.vy += this.ga * dt);
        this.y += this.vy * dt;
        this.isOnGround = false;
        this.reserveTime > 0 && (this.reserveTime -= dt);
        if (this.y <= this.baseHeight) {
          this.y = this.baseHeight;
          this.isOnGround = true;
        }
        if (!this.isOnGround) {
          this.x += this.vx * dt;
          this.vx += this.af * dt;
          this.lastIsOnGround = false;
        }
        this.enemy || this.findEnemy();
        var dis = Math.abs(this.x - this.enemy.x);
        switch (this.state) {
         case WarriorCommonState.IDLE:
          this.setAnimState(WarriorAnimState.IDLE);
          this.moveVal *= .8;
          this.x += this.moveVal * dt;
          break;

         case WarriorCommonState.STUN_DOWN:
          this.targetScaleY = .4 * this.defaultScaleY;
          if (this.stunDownTime > 0) {
            this.stunDownTime -= dt;
            this.stunDownTime <= 0 && (this.state = WarriorCommonState.STUN);
          }
          break;

         case WarriorCommonState.STUN:
          if (!this.lastIsOnGround && this.isOnGround) {
            this.state = WarriorCommonState.STUN_DOWN;
            this.stunDownTime = .05;
            this.lastIsOnGround = true;
          }
          this.targetScaleY = 1 * this.defaultScaleY;
          if (this.isOnGround && this.isDie) {
            this.setAnimState(WarriorAnimState.DIE);
            this.state = WarriorCommonState.DIE;
            break;
          }
          if (this.isOnGround && this.isWin) {
            this.setAnimState(WarriorAnimState.WIN);
            this.state = WarriorCommonState.WIN;
            this.winTime = this.winDur;
            break;
          }
          this.isOnGround && this.setAnimState(WarriorAnimState.FIGHTING_IDLE);
          this.stunTime < this.stunWait ? this.stunTime += dt : this.state = WarriorCommonState.ACTIVE;
          this.moveVal *= .8;
          this.x += this.moveVal * dt;
          break;

         case WarriorCommonState.ACTIVE:
          if (!this.isOnGround) break;
          if (this.isDie || this.isWin) {
            this.state = WarriorCommonState.STUN;
            break;
          }
          0 == this.moveVal && this.setAnimState(WarriorAnimState.FIGHTING_IDLE);
          if (dis > this.attackRange || dis < this.minAttackRange) {
            if (this.checkValidAttackDir()) {
              var val = Math.abs(this.moveVal);
              if (dis > this.attackRange) {
                val += .05 * this.moveSpeed;
                val > this.moveSpeed && (val = this.moveSpeed);
                this.moveVal = this.dir * val;
                this.x += this.moveVal * dt;
                this.setAnimState(WarriorAnimState.RUN);
              } else {
                val += .05 * this.moveSpeed;
                val > this.moveSpeed && (val = this.moveSpeed);
                this.moveVal = -this.dir * val;
                this.x += this.moveVal * dt * .8;
                this.setAnimState(WarriorAnimState.BACKWARD);
              }
            }
          } else {
            this.moveVal *= .8;
            Math.abs(this.moveVal) < 1 && (this.moveVal = 0);
            this.x += this.moveVal * dt;
            if (this.reserveTime > 0) break;
            if (!this.checkValidAttackDir()) break;
            if (this.world.resting) break;
            if (this.chooseSkill(dt)) {
              this.moveVal = 0;
              this.state = WarriorCommonState.FIGHTING;
            } else this.setAnimState(WarriorAnimState.FIGHTING_IDLE);
          }
          break;

         case WarriorCommonState.FIGHTING:
          this.updateFighting(dt);
          break;

         case WarriorCommonState.DIE:
          break;

         case WarriorCommonState.WIN:
          this.winTime -= dt;
          this.winTime <= 0 && (this.state = WarriorCommonState.IDLE);
        }
      };
      BaseWarrior.prototype.chooseSkill = function(dt) {
        return false;
      };
      BaseWarrior.prototype.useSkill = function(ind) {
        this.activeSkill = this.skills[ind];
        this.activeSkill.start();
      };
      BaseWarrior.prototype.stopSkill = function() {
        if (this.activeSkill) {
          this.activeSkill.done();
          this.activeSkill = null;
        }
      };
      BaseWarrior.prototype.onSkillDone = function() {
        this.activeSkill = null;
      };
      BaseWarrior.prototype.hurt = function(damage, stunDur) {
        void 0 === stunDur && (stunDur = .2);
        cc.log("hurt == " + this.name);
        this.stopSkill();
        this.setStunFor(stunDur);
        this.setHp(this.hp - damage);
        this.hp <= 0 && this.die();
      };
      BaseWarrior.prototype.setHp = function(hp) {
        hp < 0 && (hp = 0);
        hp > this.totalHp && (hp = this.totalHp);
        this.hp = hp;
        this.world.onWarriorHpChange(this);
      };
      BaseWarrior.prototype.die = function() {
        this.world.onWarriorDie(this);
        this.isDie = true;
      };
      BaseWarrior.prototype.win = function() {
        this.isWin = true;
      };
      BaseWarrior.prototype.updateFighting = function(dt) {};
      BaseWarrior.prototype.setDir = function(dir) {
        if (!this.isOnGround) return;
        dir != this.dir && this.setStunFor(.2);
        this.dir = dir;
        this.scaleX = dir;
      };
      BaseWarrior.prototype.setStunFor = function(wait) {
        this.stunTime = 0;
        this.state = WarriorCommonState.STUN;
        this.stunWait = wait;
      };
      BaseWarrior.prototype.checkValidAttackDir = function() {
        var moveDir = this.enemy.x - this.x >= 0 ? 1 : -1;
        if (this.dir != moveDir) {
          this.setDir(moveDir);
          return false;
        }
        return true;
      };
      BaseWarrior.prototype.findEnemy = function() {
        var wars = this.world.getChildren();
        for (var i = 0; i < wars.length; i++) {
          var war = wars[i];
          if (war != this) {
            this.enemy = war;
            break;
          }
        }
      };
      return BaseWarrior;
    }(VBaseNode_1.VBaseNode);
    exports.BaseWarrior = BaseWarrior;
    cc._RF.pop();
  }, {
    "./EnvSettings": "EnvSettings",
    "./VBaseNode": "VBaseNode"
  } ],
  ChickFighter: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "4e7423uQ45Lca8x50JCrRHp", "ChickFighter");
    "use strict";
    var __extends = this && this.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function(d, b) {
          d.__proto__ = b;
        } || function(d, b) {
          for (var p in b) b.hasOwnProperty(p) && (d[p] = b[p]);
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = null === b ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var BaseWarrior_1 = require("./BaseWarrior");
    var BaseSkill_1 = require("./BaseSkill");
    var EnvSettings_1 = require("./EnvSettings");
    var ChickFighter = function(_super) {
      __extends(ChickFighter, _super);
      function ChickFighter(world) {
        var _this = _super.call(this, world) || this;
        var kick = new BaseSkill_1.KickSkill();
        kick.setOwner(_this);
        _this.skills[ChickFighter.SKILL_KICK] = kick;
        var dodge = new BaseSkill_1.LowDodgeSkill();
        dodge.setOwner(_this);
        _this.skills[ChickFighter.LOW_DODGE] = dodge;
        _this.animStateMap[BaseWarrior_1.WarriorAnimState.IDLE] = "IdleStrong";
        _this.animLoopMap[BaseWarrior_1.WarriorAnimState.IDLE] = true;
        _this.animStateMap[BaseWarrior_1.WarriorAnimState.RUN] = "WalkForward50";
        _this.animLoopMap[BaseWarrior_1.WarriorAnimState.RUN] = true;
        _this.animStateMap[BaseWarrior_1.WarriorAnimState.BACKWARD] = "WalkBackward50";
        _this.animLoopMap[BaseWarrior_1.WarriorAnimState.BACKWARD] = true;
        _this.animStateMap[BaseWarrior_1.WarriorAnimState.FIGHTING_IDLE] = "IdleThreaten2";
        _this.animLoopMap[BaseWarrior_1.WarriorAnimState.FIGHTING_IDLE] = true;
        _this.animStateMap[BaseWarrior_1.WarriorAnimState.JUMP_HIGHT_BACKWARD] = "JumpHighBackward";
        _this.animLoopMap[BaseWarrior_1.WarriorAnimState.JUMP_HIGHT_BACKWARD] = true;
        _this.animStateMap[BaseWarrior_1.WarriorAnimState.JUMP_HIGHT_FORWARD] = "JumpHighForward";
        _this.animLoopMap[BaseWarrior_1.WarriorAnimState.JUMP_HIGHT_FORWARD] = true;
        _this.animStateMap[BaseWarrior_1.WarriorAnimState.ATTACK_MIDDLE_1] = "AttackMid1";
        _this.animLoopMap[BaseWarrior_1.WarriorAnimState.ATTACK_MIDDLE_1] = false;
        _this.animStateMap[BaseWarrior_1.WarriorAnimState.LANDING] = "Landing";
        _this.animLoopMap[BaseWarrior_1.WarriorAnimState.LANDING] = false;
        _this.animStateMap[BaseWarrior_1.WarriorAnimState.FALLING] = "LandingFail";
        _this.animLoopMap[BaseWarrior_1.WarriorAnimState.FALLING] = false;
        _this.animStateMap[BaseWarrior_1.WarriorAnimState.DIE] = "DieGround";
        _this.animLoopMap[BaseWarrior_1.WarriorAnimState.DIE] = false;
        _this.animStateMap[BaseWarrior_1.WarriorAnimState.WIN] = "Win";
        _this.animLoopMap[BaseWarrior_1.WarriorAnimState.WIN] = false;
        _this.animStateMap[BaseWarrior_1.WarriorAnimState.DOWN] = "Crouch";
        _this.animLoopMap[BaseWarrior_1.WarriorAnimState.DOWN] = false;
        _this.transDurMap[BaseWarrior_1.WarriorAnimState.IDLE + "__" + BaseWarrior_1.WarriorAnimState.RUN] = .03;
        _this.transDurMap[BaseWarrior_1.WarriorAnimState.FIGHTING_IDLE + "__" + BaseWarrior_1.WarriorAnimState.RUN] = .03;
        _this.transDurMap[BaseWarrior_1.WarriorAnimState.RUN + "__" + BaseWarrior_1.WarriorAnimState.FIGHTING_IDLE] = .1;
        _this.transDurMap[BaseWarrior_1.WarriorAnimState.RUN + "__" + BaseWarrior_1.WarriorAnimState.IDLE] = .1;
        _this.transDurMap[BaseWarrior_1.WarriorAnimState.WIN + "__" + BaseWarrior_1.WarriorAnimState.IDLE] = .5;
        _this.transDurMap[BaseWarrior_1.WarriorAnimState.LANDING + "__" + BaseWarrior_1.WarriorAnimState.FIGHTING_IDLE] = 0;
        _this.transDurMap[BaseWarrior_1.WarriorAnimState.FALLING + "__" + BaseWarrior_1.WarriorAnimState.FIGHTING_IDLE] = 0;
        _this.transDurMap[BaseWarrior_1.WarriorAnimState.LANDING + "__" + BaseWarrior_1.WarriorAnimState.DOWN] = 0;
        _this.transDurMap[BaseWarrior_1.WarriorAnimState.FALLING + "__" + BaseWarrior_1.WarriorAnimState.DOWN] = 0;
        _this.transDurMap[BaseWarrior_1.WarriorAnimState.JUMP_HIGHT_FORWARD + "__" + BaseWarrior_1.WarriorAnimState.LANDING] = .15;
        _this.transDurMap[BaseWarrior_1.WarriorAnimState.ATTACK_MIDDLE_1 + "__" + BaseWarrior_1.WarriorAnimState.LANDING] = .15;
        _this.transDurMap[BaseWarrior_1.WarriorAnimState.DOWN + "__" + BaseWarrior_1.WarriorAnimState.FIGHTING_IDLE] = .1;
        _this.transDurMap[BaseWarrior_1.WarriorAnimState.JUMP_HIGHT_BACKWARD + "__" + BaseWarrior_1.WarriorAnimState.ATTACK_MIDDLE_1] = .05;
        return _this;
      }
      ChickFighter.prototype.updateFighting = function(dt) {
        _super.prototype.updateFighting.call(this, dt);
        this.activeSkill && !this.activeSkill.isDone && this.activeSkill.update(dt);
      };
      ChickFighter.prototype.hurt = function(damage, stunDur) {
        void 0 === stunDur && (stunDur = .2);
        _super.prototype.hurt.call(this, damage);
        this.isOnGround || this.setAnimState(BaseWarrior_1.WarriorAnimState.FALLING);
      };
      ChickFighter.prototype.chooseSkill = function(dt) {
        if (this.activeSkill) return false;
        var enemy = this.enemy;
        var world = this.world;
        var used = false;
        if (!used && enemy.y > 1.1 * enemy.baseHeight) {
          var dodgeSkill = this.skills[ChickFighter.LOW_DODGE];
          if (this.x < .2 * EnvSettings_1.default.SCREEN_W || this.x > .8 * EnvSettings_1.default.SCREEN_W) {
            used = true;
            this.useSkill(ChickFighter.LOW_DODGE);
            dodgeSkill.dodgeDis = 500 + 200 * this.world.getRand();
          } else if (world.getRand() < .15) {
            used = true;
            dodgeSkill.dodgeDis = 300;
            this.useSkill(ChickFighter.LOW_DODGE);
          }
        }
        if (!used && enemy.getIsOnGround() && world.getRand() < .3) {
          used = true;
          this.useSkill(ChickFighter.SKILL_KICK);
        }
        return used;
      };
      ChickFighter.prototype.playAnim = function(state) {
        if (!this.animStateMap[state]) return;
        if (!this.anim) return;
        this.mixAnimTime = 0;
        this.curAnimState = state;
        var track = 0;
        var spine = this.anim.getComponent(sp.Skeleton);
        spine.setAnimation(track, this.animStateMap[state], this.animLoopMap[state]);
        spine.timeScale = 1;
      };
      ChickFighter.prototype.mixAnim = function(state) {
        if (!this.animStateMap[state]) return;
        var fromTo = this.curAnimState + "__" + state;
        var transDur = this.transDurMap[fromTo];
        void 0 == transDur && (transDur = .05);
        if (this.curAnimState < 0 || 0 == transDur) {
          this.playAnim(state);
          return;
        }
        this.mixAnimTime = transDur;
        var spine = this.anim.getComponent(sp.Skeleton);
        spine.setMix(this.animStateMap[this.curAnimState], this.animStateMap[state], transDur);
        this.curAnimState = state;
      };
      ChickFighter.prototype.update = function(dt) {
        _super.prototype.update.call(this, dt);
        if (this.anim) {
          this.anim.scaleY += .15 * (this.targetScaleY - this.anim.scaleY);
          switch (this.curAnimState) {
           case BaseWarrior_1.WarriorAnimState.RUN:
           case BaseWarrior_1.WarriorAnimState.BACKWARD:
            var spine = this.anim.getComponent(sp.Skeleton);
            var timeScale = this.world.baseTimeScale * Math.abs(this.moveVal) / 120;
            timeScale < this.world.baseTimeScale && (timeScale = this.world.baseTimeScale);
            spine.timeScale = timeScale;
          }
        }
        if (this.mixAnimTime > 0) {
          this.mixAnimTime -= dt;
          this.mixAnimTime <= 0 && this.playAnim(this.curAnimState);
        }
      };
      ChickFighter.SKILL_KICK = 0;
      ChickFighter.LOW_DODGE = 1;
      return ChickFighter;
    }(BaseWarrior_1.BaseWarrior);
    exports.ChickFighter = ChickFighter;
    cc._RF.pop();
  }, {
    "./BaseSkill": "BaseSkill",
    "./BaseWarrior": "BaseWarrior",
    "./EnvSettings": "EnvSettings"
  } ],
  ChickGame: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "1d672LAF1BIhqg37CUtRq2h", "ChickGame");
    "use strict";
    var __extends = this && this.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function(d, b) {
          d.__proto__ = b;
        } || function(d, b) {
          for (var p in b) b.hasOwnProperty(p) && (d[p] = b[p]);
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = null === b ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    var __decorate = this && this.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : null === desc ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if ("object" === typeof Reflect && "function" === typeof Reflect.decorate) r = Reflect.decorate(decorators, target, key, desc); else for (var i = decorators.length - 1; i >= 0; i--) (d = decorators[i]) && (r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r);
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var World_1 = require("./World");
    var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
    var ChickGame = function(_super) {
      __extends(ChickGame, _super);
      function ChickGame() {
        var _this = null !== _super && _super.apply(this, arguments) || this;
        _this.timeTf = null;
        _this.chick1 = null;
        _this.chick2 = null;
        _this.hit1 = null;
        _this.hit2 = null;
        _this.hpBar1 = null;
        _this.hpBar2 = null;
        _this.anim1 = null;
        _this.anim2 = null;
        return _this;
      }
      ChickGame.prototype.onLoad = function() {
        this.world = new World_1.World();
        this.world.updateUIHpHdl = this.updateUIHpHdl.bind(this);
        this.world.chick1.setAnim(this.anim1);
        this.world.chick2.setAnim(this.anim2);
        this.world.reset();
        this.world.onGameEndedHdl = this.onGameEnded.bind(this);
        var _deltaTime = 0;
        var timeScaleAttibute = cc.js.getPropertyDescriptor(cc.director, "_deltaTime");
        Object.defineProperty(cc.director, "_deltaTime", {
          get: function() {
            var r = _deltaTime * cc.director.getScheduler().getTimeScale();
            return r;
          },
          set: function(value) {
            _deltaTime = value;
          },
          enumerable: true,
          configurable: true
        });
        cc.director.getScheduler().setTimeScale(this.world.baseTimeScale);
      };
      ChickGame.prototype.start = function() {};
      ChickGame.prototype.onStartFighting = function() {
        this.world.reset();
        this.world.startFighting();
        this.gameStarted = true;
        this.battleTime = 0;
      };
      ChickGame.prototype.onGameEnded = function() {
        this.gameStarted = false;
      };
      ChickGame.prototype.update = function(dt) {
        this.world.update(dt);
        if (this.gameStarted) {
          this.battleTime += dt;
          this.timeTf.string = Math.round(this.battleTime).toString();
        }
        var wc1 = this.world.chick1;
        var wc2 = this.world.chick2;
        var c1 = this.chick1;
        var c2 = this.chick2;
        c1.x = wc1.x;
        c1.y = wc1.y;
        c1.scaleX = wc1.scaleX;
        c2.x = wc2.x;
        c2.y = wc2.y;
        c2.scaleX = wc2.scaleX;
        var p1 = wc1.toGlobal(wc1.skills[0].hitPos);
        var p2 = wc2.toGlobal(wc2.skills[0].hitPos);
        this.hit1.x = p1.x;
        this.hit1.y = p1.y;
        this.hit2.x = p2.x;
        this.hit2.y = p2.y;
      };
      ChickGame.prototype.updateUIHpHdl = function(chick) {
        var hpBar = chick == this.world.chick1 ? this.hpBar1 : this.hpBar2;
        hpBar.progress = chick.getHp() / chick.totalHp;
      };
      __decorate([ property(cc.Label) ], ChickGame.prototype, "timeTf", void 0);
      __decorate([ property(cc.Node) ], ChickGame.prototype, "chick1", void 0);
      __decorate([ property(cc.Node) ], ChickGame.prototype, "chick2", void 0);
      __decorate([ property(cc.Node) ], ChickGame.prototype, "hit1", void 0);
      __decorate([ property(cc.Node) ], ChickGame.prototype, "hit2", void 0);
      __decorate([ property(cc.ProgressBar) ], ChickGame.prototype, "hpBar1", void 0);
      __decorate([ property(cc.ProgressBar) ], ChickGame.prototype, "hpBar2", void 0);
      __decorate([ property(cc.Node) ], ChickGame.prototype, "anim1", void 0);
      __decorate([ property(cc.Node) ], ChickGame.prototype, "anim2", void 0);
      ChickGame = __decorate([ ccclass ], ChickGame);
      return ChickGame;
    }(cc.Component);
    exports.default = ChickGame;
    cc._RF.pop();
  }, {
    "./World": "World"
  } ],
  EnvSettings: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "692d2yS74BDBJ/21KUJi7D2", "EnvSettings");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var EnvSettings = function() {
      function EnvSettings() {}
      EnvSettings.SCREEN_W = 1400;
      EnvSettings.FPS = 60;
      EnvSettings.ga = -9.81 * EnvSettings.FPS * 5;
      EnvSettings.af = .1 * EnvSettings.FPS;
      return EnvSettings;
    }();
    exports.default = EnvSettings;
    cc._RF.pop();
  }, {} ],
  VBaseNode: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "653c1gCPhROo7fEpsOtdePv", "VBaseNode");
    "use strict";
    var __extends = this && this.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function(d, b) {
          d.__proto__ = b;
        } || function(d, b) {
          for (var p in b) b.hasOwnProperty(p) && (d[p] = b[p]);
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = null === b ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var VBaseTransform_1 = require("./VBaseTransform");
    var VBaseNode = function(_super) {
      __extends(VBaseNode, _super);
      function VBaseNode() {
        var _this = _super.call(this) || this;
        _this.parent = null;
        _this.children = [];
        return _this;
      }
      VBaseNode.prototype.update = function(dt) {
        for (var i = 0; i < this.children.length; i++) this.children[i].update(dt);
      };
      VBaseNode.prototype.getChildren = function() {
        return this.children;
      };
      VBaseNode.prototype.getParent = function() {
        return this.parent;
      };
      VBaseNode.prototype.setParent = function(p) {
        this.parent && this.parent.removeChild(this);
        this.parent = p;
      };
      VBaseNode.prototype.addChild = function(child) {
        child.setParent(this);
        this.children.push(child);
      };
      VBaseNode.prototype.removeChild = function(child) {
        for (var i = 0; i < this.children.length; i++) if (this.children[i] === child) {
          this.children.splice(i, 1);
          break;
        }
        child.setParent(null);
      };
      VBaseNode.prototype.toGlobal = function(p) {
        var t = this.getTransform();
        var par = this.parent;
        while (par) {
          t = VBaseTransform_1.Mat3.multiply(par.getTransform(), t);
          par = par.parent;
        }
        return this.applyTransform(t, p);
      };
      VBaseNode.prototype.toLocal = function(p) {
        var t = this.getTransform();
        var par = this.parent;
        while (par) {
          t = VBaseTransform_1.Mat3.multiply(par.getTransform(), t);
          par = par.parent;
        }
        t = VBaseTransform_1.Mat3.getInvert(t);
        return this.applyTransform(t, p);
      };
      return VBaseNode;
    }(VBaseTransform_1.VBaseTransform);
    exports.VBaseNode = VBaseNode;
    cc._RF.pop();
  }, {
    "./VBaseTransform": "VBaseTransform"
  } ],
  VBaseTransform: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "a43f7EN65pLX6z/fHBmMaXQ", "VBaseTransform");
    "use strict";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var VVec2 = function() {
      function VVec2(x, y) {
        void 0 === x && (x = 0);
        void 0 === y && (y = 0);
        this.x = x;
        this.y = y;
      }
      VVec2.prototype.rotate = function(ang) {
        var v = new VVec2();
        v.x = Math.cos(ang) * this.x - Math.sin(ang) * this.y;
        v.y = Math.sin(ang) * this.x + Math.cos(ang) * this.y;
        return v;
      };
      VVec2.prototype.normalize = function() {
        var m = Math.sqrt(this.x * this.x + this.y * this.y);
        if (1 == m) return;
        this.x /= m;
        this.y /= m;
      };
      VVec2.prototype.scale = function(s) {
        this.x *= s;
        this.y *= s;
      };
      VVec2.prototype.getNorm = function() {
        return Math.sqrt(this.x * this.x + this.y * this.y);
      };
      VVec2.prototype.getAng = function(v) {
        var ang = Math.acos((this.x * v.x + this.y * v.y) / (Math.sqrt(this.x * this.x + this.y * this.y) * Math.sqrt(v.x * v.x + v.y * v.y)));
        var vy = this.y * v.x - this.x * v.y;
        return ang;
      };
      VVec2.prototype.getAng2 = function(v) {
        var ang = Math.acos((this.x * v.x + this.y * v.y) / (Math.sqrt(this.x * this.x + this.y * this.y) * Math.sqrt(v.x * v.x + v.y * v.y)));
        var vy = this.y * v.x - this.x * v.y;
        vy < 0 && (ang = -ang);
        return ang;
      };
      return VVec2;
    }();
    exports.VVec2 = VVec2;
    var VVec3 = function() {
      function VVec3(x, y, z) {
        void 0 === x && (x = 0);
        void 0 === y && (y = 0);
        void 0 === z && (z = 0);
        this.x = x;
        this.y = y;
        this.z = z;
      }
      VVec3.prototype.getModule = function() {
        return Math.abs(this.x * this.x + this.y * this.y + this.z * this.z);
      };
      return VVec3;
    }();
    exports.VVec3 = VVec3;
    var Mat3 = function() {
      function Mat3() {}
      Mat3.multiply = function(a, b) {
        var out = [];
        var a00 = a[0], a01 = a[1], a02 = a[2];
        var a10 = a[3], a11 = a[4], a12 = a[5];
        var a20 = a[6], a21 = a[7], a22 = a[8];
        var b00 = b[0], b01 = b[1], b02 = b[2];
        var b10 = b[3], b11 = b[4], b12 = b[5];
        var b20 = b[6], b21 = b[7], b22 = b[8];
        out[0] = b00 * a00 + b01 * a10 + b02 * a20;
        out[1] = b00 * a01 + b01 * a11 + b02 * a21;
        out[2] = b00 * a02 + b01 * a12 + b02 * a22;
        out[3] = b10 * a00 + b11 * a10 + b12 * a20;
        out[4] = b10 * a01 + b11 * a11 + b12 * a21;
        out[5] = b10 * a02 + b11 * a12 + b12 * a22;
        out[6] = b20 * a00 + b21 * a10 + b22 * a20;
        out[7] = b20 * a01 + b21 * a11 + b22 * a21;
        out[8] = b20 * a02 + b21 * a12 + b22 * a22;
        return out;
      };
      Mat3.getInvert = function(a) {
        var out = [];
        var a00 = a[0], a01 = a[1], a02 = a[2];
        var a10 = a[3], a11 = a[4], a12 = a[5];
        var a20 = a[6], a21 = a[7], a22 = a[8];
        var b01 = a22 * a11 - a12 * a21;
        var b11 = -a22 * a10 + a12 * a20;
        var b21 = a21 * a10 - a11 * a20;
        var det = a00 * b01 + a01 * b11 + a02 * b21;
        if (!det) return null;
        det = 1 / det;
        out[0] = b01 * det;
        out[1] = (-a22 * a01 + a02 * a21) * det;
        out[2] = (a12 * a01 - a02 * a11) * det;
        out[3] = b11 * det;
        out[4] = (a22 * a00 - a02 * a20) * det;
        out[5] = (-a12 * a00 + a02 * a10) * det;
        out[6] = b21 * det;
        out[7] = (-a21 * a00 + a01 * a20) * det;
        out[8] = (a11 * a00 - a01 * a10) * det;
        return out;
      };
      return Mat3;
    }();
    exports.Mat3 = Mat3;
    var VBaseTransform = function() {
      function VBaseTransform() {
        this.resetTransform();
      }
      VBaseTransform.prototype.resetTransform = function() {
        this.scaleX = 1;
        this.scaleY = 1;
        this.skewY = 0;
        this.skewX = 0;
        this.x = 0;
        this.y = 0;
        this.rot = 0;
      };
      VBaseTransform.prototype.getTransform = function() {
        var m = [ this.scaleX, this.skewX, this.x, this.skewY, this.scaleY, this.y, 0, 0, 1 ];
        var rm = [ Math.cos(this.rot), -Math.sin(this.rot), 0, Math.sin(this.rot), Math.cos(this.rot), 0, 0, 0, 1 ];
        var mm = Mat3.multiply(m, rm);
        return mm;
      };
      VBaseTransform.prototype.applyTransform = function(t, p) {
        return new VVec2(t[0] * p.x + t[1] * p.y + t[2], t[3] * p.x + t[4] * p.y + t[5]);
      };
      return VBaseTransform;
    }();
    exports.VBaseTransform = VBaseTransform;
    cc._RF.pop();
  }, {} ],
  World: [ function(require, module, exports) {
    "use strict";
    cc._RF.push(module, "fa681CF3npOE44P0O1GY5Pz", "World");
    "use strict";
    var __extends = this && this.__extends || function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function(d, b) {
          d.__proto__ = b;
        } || function(d, b) {
          for (var p in b) b.hasOwnProperty(p) && (d[p] = b[p]);
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = null === b ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    var VBaseNode_1 = require("./VBaseNode");
    var ChickFighter_1 = require("./ChickFighter");
    var BaseWarrior_1 = require("./BaseWarrior");
    var EnvSettings_1 = require("./EnvSettings");
    var World = function(_super) {
      __extends(World, _super);
      function World() {
        var _this = _super.call(this) || this;
        _this.baseTimeScale = 1;
        _this.chick1 = new ChickFighter_1.ChickFighter(_this);
        _this.chick2 = new ChickFighter_1.ChickFighter(_this);
        _this.chick1.skills[0].skillVy = 700;
        _this.chick1.name = "chick1";
        _this.chick2.name = "chick2";
        _this.addChild(_this.chick1);
        _this.addChild(_this.chick2);
        _this.restInterval = 0;
        _this.resting = false;
        _this.updateUIHpHdl = null;
        _this.onGameEndedHdl = null;
        return _this;
      }
      World.prototype.reset = function() {
        this.chick1.reset();
        this.chick2.reset();
        this.chick1.x = .2 * EnvSettings_1.default.SCREEN_W;
        this.chick2.x = EnvSettings_1.default.SCREEN_W - this.chick1.x;
        this.chick2.dir = -1;
        this.chick2.scaleX = -1;
        this.updateUIHpHdl(this.chick1);
        this.updateUIHpHdl(this.chick2);
      };
      World.prototype.startFighting = function() {
        this.chick1.setState(BaseWarrior_1.WarriorCommonState.ACTIVE);
        this.chick2.setState(BaseWarrior_1.WarriorCommonState.ACTIVE);
      };
      World.prototype.getRand = function() {
        return Math.random();
      };
      World.prototype.update = function(dt) {
        dt *= this.baseTimeScale;
        _super.prototype.update.call(this, dt);
        if (this.restInterval > 0) this.restInterval -= dt; else {
          this.resting = this.getRand() > .4;
          this.restInterval = 2 * this.getRand();
        }
        var c1 = this.chick1;
        var c2 = this.chick2;
        var dis = Math.abs(c1.x - c2.x);
        if (!c1.getIsOnGround() && !c2.getIsOnGround() && (c1.x - c2.x) * c2.vx > 0 && (c2.x - c1.x) * c1.vx > 0 && dis < c1.hitRadius + c2.hitRadius) {
          c1.vx = .9 * -c1.vx;
          c2.vx = .9 * -c2.vx;
        }
      };
      World.prototype.onWarriorDie = function(chick) {
        var winer = this.chick1 != chick ? this.chick1 : this.chick2;
        var loser = this.chick1 == chick ? this.chick1 : this.chick2;
        winer.win();
        this.onGameEndedHdl && this.onGameEndedHdl();
      };
      World.prototype.onWarriorHpChange = function(chick) {
        this.updateUIHpHdl && this.updateUIHpHdl(chick);
      };
      return World;
    }(VBaseNode_1.VBaseNode);
    exports.World = World;
    cc._RF.pop();
  }, {
    "./BaseWarrior": "BaseWarrior",
    "./ChickFighter": "ChickFighter",
    "./EnvSettings": "EnvSettings",
    "./VBaseNode": "VBaseNode"
  } ]
}, {}, [ "BaseSkill", "BaseWarrior", "ChickFighter", "ChickGame", "EnvSettings", "VBaseNode", "VBaseTransform", "World" ]);