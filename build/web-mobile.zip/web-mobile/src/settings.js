window._CCSettings = {
    platform: "web-mobile",
    groupList: [
        "default"
    ],
    collisionMatrix: [
        [
            true
        ]
    ],
    rawAssets: {
        assets: {},
        internal: {
            "14TDKXr2NJ6LjvHPops74o": [
                "effects/builtin-2d-gray-sprite.effect",
                "cc.EffectAsset"
            ],
            "0ek66qC1NOQLjgYmi04HvX": [
                "effects/builtin-2d-spine.effect",
                "cc.EffectAsset"
            ],
            "28dPjdQWxEQIG3VVl1Qm6T": [
                "effects/builtin-2d-sprite.effect",
                "cc.EffectAsset"
            ],
            c0BAyVxX9JzZy8EjFrc9DU: [
                "effects/builtin-clear-stencil.effect",
                "cc.EffectAsset"
            ],
            "796vrvt+9F2Zw/WR3INvx6": [
                "effects/builtin-unlit-transparent.effect",
                "cc.EffectAsset"
            ],
            "6dkeWRTOBGXICfYQ7JUBnG": [
                "effects/builtin-unlit.effect",
                "cc.EffectAsset"
            ],
            "6fgBCSDDdPMInvyNlggls2": [
                "materials/builtin-2d-base.mtl",
                "cc.Material"
            ],
            "3ae7efMv1CLq2ilvUY/tQi": [
                "materials/builtin-2d-gray-sprite.mtl",
                "cc.Material"
            ],
            "7a/QZLET9IDreTiBfRn2PD": [
                "materials/builtin-2d-spine.mtl",
                "cc.Material"
            ],
            "ecpdLyjvZBwrvm+cedCcQy": [
                "materials/builtin-2d-sprite.mtl",
                "cc.Material"
            ],
            cffgu4qBxEqa150o1DmRAy: [
                "materials/builtin-clear-stencil.mtl",
                "cc.Material"
            ],
            "2aKWBXJHxKHLvrBUi2yYZQ": [
                "materials/builtin-unlit.mtl",
                "cc.Material"
            ]
        }
    },
    launchScene: "db://assets/Scene/helloworld.fire",
    scenes: [
        {
            url: "db://assets/Scene/helloworld.fire",
            uuid: "2dL3kvpAxJu6GJ7RdqJG5J"
        }
    ],
    packedAssets: {
        "078e30dc7": [
            "29FYIk+N1GYaeWH/q1NxQO",
            "2dK5M4fGlMzo2Qqv0U+gct",
            "2dL3kvpAxJu6GJ7RdqJG5J",
            "4d/qukA81Hkqyt1ZrCPA51",
            "52Vtfq/ApD1rnXD3gQQusT",
            "675ovJ2tVK2aLYfgPUWOMv",
            "8855/VlrRKd6H0MSRnFxAU",
            "e5BU1TkDZBGa0muHI8Xon1",
            "e97GVMl6JHh5Ml5qEDdSGa",
            "f0BIwQ8D5Ml7nTNQbh1YlS"
        ],
        "079499991": [
            "2aKWBXJHxKHLvrBUi2yYZQ",
            "6dkeWRTOBGXICfYQ7JUBnG"
        ],
        "07ce7530a": [
            "14TDKXr2NJ6LjvHPops74o",
            "3ae7efMv1CLq2ilvUY/tQi"
        ],
        "0b013d441": [
            "02delMVqdBD70a/HSD99FK",
            "19qHIqt5JHioUnbg8+V4wx",
            "1ezVjuqH5M8IUmLjhCTw37",
            "71VhFCTINJM6/Ky3oX9nBT",
            "7aaxGQzRtHr5P/fa1IKSMn",
            "92bLXt66pIQYX2GiYpFAeD",
            "99FwsL0hBG8bITfZ4/IwmK",
            "b4P/PCArtIdIH38t6mlw8Y",
            "caqQHx4U9L5ZbDfD6qs93O",
            "cf73jxyN9Jt47QTJU6ziYh",
            "e8Ueib+qJEhL6mXAHdnwbi"
        ],
        "0d669730c": [
            "c0BAyVxX9JzZy8EjFrc9DU",
            "cffgu4qBxEqa150o1DmRAy"
        ],
        "0e4bc3b03": [
            "0ek66qC1NOQLjgYmi04HvX",
            "7a/QZLET9IDreTiBfRn2PD"
        ]
    },
    md5AssetsMap: {},
    orientation: "",
    debug: true,
    subpackages: {}
};
